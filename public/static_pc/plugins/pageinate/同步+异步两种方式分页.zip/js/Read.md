> layPage
>> 原生、可以直接与后端配合，达到整页翻页效果，SEO效果好
> jq_page
>> JQuery插件，api方式，Ajax拉取数据，MVVM模式，快速开发后台操作界面